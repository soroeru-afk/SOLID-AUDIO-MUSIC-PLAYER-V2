import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

code = code.replace(
    "const newWidth = Math.max(120, Math.min(400, startWidth + delta));",
    "const newWidth = Math.max(120, Math.min(800, startWidth + delta));"
)

code = code.replace(
    "maxWidth: 400,",
    "maxWidth: 800,"
)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
