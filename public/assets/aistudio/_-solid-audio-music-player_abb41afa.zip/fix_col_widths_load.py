import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

target = """        if (savedColWidths) setColWidths(prev => ({ ...prev, ...savedColWidths }));"""

replacement = """        if (savedColWidths) {
          const sanitized = { ...savedColWidths };
          Object.keys(sanitized).forEach(k => {
            if (isNaN(sanitized[k])) sanitized[k] = 100;
          });
          setColWidths(prev => ({ ...prev, ...sanitized }));
        }"""

code = code.replace(target, replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
