const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
    /              \}\)derColor: 'var\(--theme-borderActive\)', color: iconColor \}\}>\n                  <Palette size=\{10\} \/>\n                <\/button>\n            \)\}/g,
    `              )}`
);
fs.writeFileSync('src/App.tsx', code);
