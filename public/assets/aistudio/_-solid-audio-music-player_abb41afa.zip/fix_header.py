import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

target = '''                    {colOrder.map(col => {
                      if (col === 'art' && colVisibility.art) {
                  return (
                    <div key="art" className="w-8 h-8 flex-shrink-0 border flex items-center justify-center overflow-hidden relative" style={{ borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', backgroundColor: 'var(--theme-bg)', opacity: track.missing ? 0.5 : 1 }}>
                       {track.coverUrl ? (
                          <img src={track.coverUrl} className="w-full h-full object-cover" alt="" />
                       ) : (
                          <Activity size={10} style={{ color: 'var(--theme-textDim)' }} />
                       )}
                    </div>
                  );
                }
                if (col === 'fileName' && colVisibility.fileName) {'''

replacement = '''                    {colOrder.map(col => {
                      if (col === 'art' && colVisibility.art) {
                        return (
                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative w-8 flex-shrink-0 flex items-center justify-center cursor-grab mr-3">
                            ART
                            <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                            </div>
                          </div>
                        );
                      }
                      if (col === 'fileName' && colVisibility.fileName) {'''

code = code.replace(target, replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
