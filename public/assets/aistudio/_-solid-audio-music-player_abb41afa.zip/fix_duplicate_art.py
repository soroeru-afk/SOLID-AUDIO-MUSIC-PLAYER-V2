import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

target = '''                      if (col === 'art' && colVisibility.art) {
                        return (
                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative w-8 flex-shrink-0 flex items-center justify-center cursor-grab">
                            ART
                            <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                            </div>
                          </div>
                        );
                      }'''

# Replace the duplicate occurrence but leave the first one intact.
# We'll just replace the exact block that comes BEFORE trackNumber
target_with_track = target + '''
                      if (col === 'trackNumber' && colVisibility.trackNumber) {'''

replacement_with_track = '''                      if (col === 'trackNumber' && colVisibility.trackNumber) {'''

code = code.replace(target_with_track, replacement_with_track)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
