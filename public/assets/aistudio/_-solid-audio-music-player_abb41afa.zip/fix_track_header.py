import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

target = '''                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} className="relative flex-shrink-0 flex items-center justify-center pr-2" style={{ width: colWidths.trackNumber }}>'''
replacement = '''                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} className="relative flex-shrink-0 flex items-center justify-center" style={{ width: colWidths.trackNumber }}>'''
code = code.replace(target, replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
