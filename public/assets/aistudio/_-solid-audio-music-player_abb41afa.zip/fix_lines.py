import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Fix `#` header
target1 = '''                  <div className="relative w-16 flex-shrink-0 flex items-center justify-center">
                    #
                    <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                      <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                    </div>
                  </div>'''
replacement1 = '''                  <div className="relative w-16 flex-shrink-0 flex items-center justify-center">
                    #
                    <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-[var(--theme-border)] opacity-40 pointer-events-none" />
                  </div>'''
code = code.replace(target1, replacement1)

# Fix `art` header
target2 = '''                      if (col === 'art' && colVisibility.art) {
                        return (
                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative w-8 flex-shrink-0 flex items-center justify-center cursor-grab mr-3">
                            ART
                            <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                            </div>
                          </div>
                        );
                      }'''
replacement2 = '''                      if (col === 'art' && colVisibility.art) {
                        return (
                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative w-8 flex-shrink-0 flex items-center justify-center cursor-grab mr-3">
                            ART
                            <div className="absolute right-[-6px] top-0 bottom-0 w-[1px] bg-[var(--theme-border)] opacity-40 pointer-events-none" />
                          </div>
                        );
                      }'''
code = code.replace(target2, replacement2)

# Fix `trackNumber` header
target3 = '''                      if (col === 'trackNumber' && colVisibility.trackNumber) {
                        return (
                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} className="relative w-10 flex-shrink-0 flex items-center justify-center">
                            <div onClick={() => handleSort('trackNumber')} className="flex-1 min-w-0 flex items-center justify-center gap-1 cursor-pointer hover:text-[var(--theme-textMain)]">
                              #No
                              {activeSortConfig.key === 'trackNumber' && (activeSortConfig.direction === 'asc' ? <ChevronUp size={10} className="shrink-0" /> : <ChevronDown size={10} className="shrink-0" />)}
                            </div>
                            <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                            </div>
                          </div>
                        );
                      }'''
replacement3 = '''                      if (col === 'trackNumber' && colVisibility.trackNumber) {
                        return (
                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} className="relative w-10 flex-shrink-0 flex items-center justify-center pr-2">
                            <div onClick={() => handleSort('trackNumber')} className="flex-1 min-w-0 flex items-center justify-center gap-1 cursor-pointer hover:text-[var(--theme-textMain)]">
                              #No
                              {activeSortConfig.key === 'trackNumber' && (activeSortConfig.direction === 'asc' ? <ChevronUp size={10} className="shrink-0" /> : <ChevronDown size={10} className="shrink-0" />)}
                            </div>
                            <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-[var(--theme-border)] opacity-40 pointer-events-none" />
                          </div>
                        );
                      }'''
code = code.replace(target3, replacement3)


with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
