import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# 1. Update initial colOrder state
code = code.replace(
    "const [colOrder, setColOrder] = useState<string[]>([\n    'fileName', 'trackNumber', 'title', 'artist', 'album'\n  ]);",
    "const [colOrder, setColOrder] = useState<string[]>([\n    'art', 'fileName', 'trackNumber', 'title', 'artist', 'album'\n  ]);"
)

# 2. Update the localstorage load in useEffect
load_target = '''        if (savedColOrder) setColOrder(savedColOrder);'''
load_replacement = '''        if (savedColOrder) {
          if (!savedColOrder.includes('art')) savedColOrder = ['art', ...savedColOrder];
          setColOrder(savedColOrder);
        } else {
          setColOrder(['art', 'fileName', 'trackNumber', 'title', 'artist', 'album']);
        }'''
code = code.replace(load_target, load_replacement)

# 3. Remove hardcoded ART in the header
header_target = '''                  <div className="w-10 flex-shrink-0 text-center">#</div>
                  {colVisibility.art && <div className="w-8 mr-3 text-center">ART</div>}
                  <div className="flex items-center gap-3">'''
header_replacement = '''                  <div className="w-10 flex-shrink-0 text-center">#</div>
                  <div className="flex items-center gap-3">'''
code = code.replace(header_target, header_replacement)

# 4. Remove hardcoded ART in the track row
row_art_target = '''          </div>
          {/* List Album Art Small */}
          {colVisibility.art && (
            <div 
              className="w-8 h-8 flex-shrink-0 mr-3 border flex items-center justify-center overflow-hidden relative"
              style={{ 
                borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', 
                backgroundColor: 'var(--theme-bg)',
                opacity: track.missing ? 0.5 : 1
              }}
            >
               {track.coverUrl ? (
                  <img src={track.coverUrl} className="w-full h-full object-cover" alt="" />
               ) : (
                  <Activity size={10} style={{ color: 'var(--theme-textDim)' }} />
               )}
            </div>
          )}
          
          {/* Track Info with Inline Edit */}'''
row_art_replacement = '''          </div>
          {/* Track Info with Inline Edit */}'''
code = code.replace(row_art_target, row_art_replacement)


# 5. Update the colOrder.map in track row
row_map_target = '''                if (col === 'fileName' && colVisibility.fileName) {'''
row_map_replacement = '''                if (col === 'art' && colVisibility.art) {
                  return (
                    <div key="art" className="w-8 h-8 flex-shrink-0 border flex items-center justify-center overflow-hidden relative" style={{ borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', backgroundColor: 'var(--theme-bg)', opacity: track.missing ? 0.5 : 1 }}>
                       {track.coverUrl ? (
                          <img src={track.coverUrl} className="w-full h-full object-cover" alt="" />
                       ) : (
                          <Activity size={10} style={{ color: 'var(--theme-textDim)' }} />
                       )}
                    </div>
                  );
                }
                if (col === 'fileName' && colVisibility.fileName) {'''
code = code.replace(row_map_target, row_map_replacement)

# 6. Update trackNumber in track row to match other columns (it was correct, but maybe add key?)
# already has key="trackNumber"

# 7. Update colOrder.map in header to include art and separator for trackNumber
header_map_target = '''                      if (col === 'trackNumber' && colVisibility.trackNumber) {
                        return (
                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} onClick={() => handleSort('trackNumber')} className="w-10 flex-shrink-0 flex items-center justify-center gap-1 cursor-pointer hover:text-[var(--theme-textMain)]">
                            #No
                            {activeSortConfig.key === 'trackNumber' && (activeSortConfig.direction === 'asc' ? <ChevronUp size={10} /> : <ChevronDown size={10} />)}
                          </div>
                        );
                      }'''
header_map_replacement = '''                      if (col === 'art' && colVisibility.art) {
                        return (
                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative w-8 flex-shrink-0 flex items-center justify-center cursor-grab">
                            ART
                            <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                            </div>
                          </div>
                        );
                      }
                      if (col === 'trackNumber' && colVisibility.trackNumber) {
                        return (
                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} className="relative w-10 flex-shrink-0 flex items-center justify-center">
                            <div onClick={() => handleSort('trackNumber')} className="flex-1 min-w-0 flex items-center justify-center gap-1 cursor-pointer hover:text-[var(--theme-textMain)]">
                              #No
                              {activeSortConfig.key === 'trackNumber' && (activeSortConfig.direction === 'asc' ? <ChevronUp size={10} className="shrink-0" /> : <ChevronDown size={10} className="shrink-0" />)}
                            </div>
                            <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                            </div>
                          </div>
                        );
                      }'''
code = code.replace(header_map_target, header_map_replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
